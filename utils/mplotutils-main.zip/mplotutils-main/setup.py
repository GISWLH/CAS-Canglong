from setuptools import setup

setup(use_scm_version={"fallback_version": "999", "version_scheme": "no-guess-dev"})
